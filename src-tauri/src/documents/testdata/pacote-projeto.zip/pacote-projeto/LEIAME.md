# Pacote de exemplo

Arquivo usado nas fixtures de preview de ZIP.
