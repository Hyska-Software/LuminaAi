def main():
    print('ola, Lumina')


if __name__ == '__main__':
    main()
